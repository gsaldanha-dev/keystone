#!/bin/bash
# Resgate da Keystone: use quando o botão não liga e o "Consertar conexão" não resolve.
# Desfaz qualquer configuração estranha no WARP, reabre a Keystone e espera o túnel voltar.
# Uso: ./resgate.sh
W="warp-cli --accept-tos"
# Edição de clientes: VPN completa, sem o proxy local.
MODE=proxy; PROXY="--proxy socks5h://127.0.0.1:40000"
if [ -f /Applications/Keystone.app/Contents/Resources/completa.txt ]; then MODE=tunnel_only; PROXY=""; fi

echo "1/4 Fechando a Keystone..."
pkill -f /Applications/Keystone.app/Contents/MacOS/Keystone; sleep 1

echo "2/4 Voltando o WARP para a configuração da Keystone..."
$W disconnect >/dev/null 2>&1
$W status 2>/dev/null | grep -q "Registration Missing" && $W registration new >/dev/null 2>&1
$W tunnel endpoint reset >/dev/null 2>&1      # servidor/porta fixos (causa do 20/10)
$W tunnel masque-options reset >/dev/null 2>&1
$W tunnel ip reset >/dev/null 2>&1
$W mode $MODE >/dev/null 2>&1
$W tunnel protocol set MASQUE >/dev/null 2>&1
$W tunnel masque-options set h2-only >/dev/null 2>&1

echo "3/4 Abrindo a Keystone..."
defaults write local.gustavo.keystone wantOn -bool true
open /Applications/Keystone.app

echo "4/4 Esperando o túnel (até 2 min)..."
for i in $(seq 1 120); do
  if curl -s -m 3 $PROXY https://www.cloudflare.com/cdn-cgi/trace 2>/dev/null | grep -q warp=on; then
    echo "✓ Túnel de volta em ${i}s. Se o Chrome ainda mostrar bloqueio, recarregue com ⌘⇧R."
    exit 0
  fi
  sleep 1
done
echo "✗ Não voltou em 2 min. Rode ./diagnostico.sh e guarde o relatório."
exit 1
